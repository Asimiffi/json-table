# Getting Started with Create React App


First create a react app through command npx-create-react-app my-app
This will create a folder my-app inside your working directory


# Replace the files I provided with the files created throught create-react-app command
Then replace public folder, source folder (all files) and packge.json file with the files I have provided you with

## Install All dependencies

Install all dependencies by going in to the directory (my-app) and running npm install

### `npm start`
then run "npm start" (command inside my-app directory) to run the app in your browser http://localhost:3000"
